import React, { useState } from 'react';
import axios from 'axios';
import SearchBar from './components/SearchBar';
import ResultCard from './components/ResultCard';

function App() {
  const [searchInput, setSearchInput] = useState('');
  const [variations, setVariations] = useState(null);

  // 🔍 Search word from backend
  const handleSearch = async () => {
    if (!searchInput.trim()) return;

    try {
      const response = await axios.get('http://localhost:5000/api/dictionary/search', {
        params: { word: searchInput }
      });
      setVariations(response.data.variations || []);
    } catch (error) {
      console.error('Error fetching dictionary:', error);
      setVariations([]);
    }
  };

  // ➕ Add variation to existing word
  const handleAddVariation = async () => {
    const key = prompt("Enter the existing word:");
    const variation = prompt("Enter the new variation:");

    if (!key || !variation) return;

    try {
      const response = await axios.post('http://localhost:5000/api/dictionary/add', {
        word: key,
        variation
      });
      alert(response.data.message);
    } catch (error) {
      console.error('Error adding variation:', error);
      alert("Failed to add variation");
    }
  };

  // 🆕 Create a new key with variations
  const handleCreateKey = async () => {
    const key = prompt("Enter the new word:");
    const value = prompt("Enter comma-separated variations:");

    if (!key || !value) return;

    const variations = value.split(',').map(v => v.trim());

    try {
      const response = await axios.post('http://localhost:5000/api/dictionary/create-key', {
        word: key,
        variations
      });
      alert(response.data.message);
    } catch (error) {
      console.error('Error creating word:', error);
      alert("Failed to create word");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-6">
        Arabizi Normalization Dictionary
      </h1>

      <div className="max-w-xl mx-auto space-y-6">
        <SearchBar
          searchInput={searchInput}
          setSearchInput={setSearchInput}
          onSearch={handleSearch}
          onAdd={handleAddVariation}
          onCreate={handleCreateKey}
        />

        {variations && (
          <ResultCard word={searchInput} variations={variations} />
        )}
      </div>
    </div>
  );
}

export default App;
