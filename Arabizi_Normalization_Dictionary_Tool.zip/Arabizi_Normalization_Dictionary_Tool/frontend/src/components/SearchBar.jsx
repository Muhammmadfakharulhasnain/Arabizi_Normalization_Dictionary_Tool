import React from 'react';

const SearchBar = ({ searchInput, setSearchInput, onSearch, onAdd, onCreate }) => {
  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex w-full max-w-md">
        <input
          type="text"
          placeholder="Type a word..."
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          className="flex-1 px-4 py-2 border rounded-l-lg border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400"
        />
        <button
          onClick={onSearch}
          className="px-4 py-2 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700"
        >
          Search
        </button>
      </div>

      <div className="flex gap-4">
        <button
          onClick={onAdd}
          className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600"
        >
          Add Variation
        </button>
        <button
          onClick={onCreate}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          Create New word
        </button>
      </div>
    </div>
  );
};

export default SearchBar;
