import React from 'react';

const ResultCard = ({ word, variations }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold text-gray-800 mb-2">Key: {word}</h2>
      <ul className="list-disc list-inside text-gray-700">
        {variations.length > 0 ? (
          variations.map((variation, index) => (
            <li key={index}>{variation}</li>
          ))
        ) : (
          <li className="italic text-gray-400">No variations found.</li>
        )}
      </ul>
    </div>
  );
};

export default ResultCard;
