const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Load dictionary.json
const dictionaryPath = path.join(__dirname, '../data/dictionary.json');

// Read dictionary
const readDictionary = () => {
  const data = fs.readFileSync(dictionaryPath, 'utf8');
  return JSON.parse(data);
};

// Write dictionary
const writeDictionary = (data) => {
  fs.writeFileSync(dictionaryPath, JSON.stringify(data, null, 2));
};

// GET /search?word=kifak
router.get('/search', (req, res) => {
  const word = req.query.word;
  const dictionary = readDictionary();

  if (!word || !dictionary[word]) {
    return res.json({ variations: [] });
  }

  return res.json({ variations: dictionary[word] });
});

// POST /add
router.post('/add', (req, res) => {
  const { word, variation } = req.body;
  const dictionary = readDictionary();

  if (!word || !variation) {
    return res.status(400).json({ message: 'Missing word or variation' });
  }

  if (!dictionary[word]) {
    dictionary[word] = [];
  }

  dictionary[word].push(variation);
  writeDictionary(dictionary);

  res.json({ message: 'Variation added successfully' });
});

// POST /create-key
router.post('/create-key', (req, res) => {
  const { word, variations } = req.body;
  const dictionary = readDictionary();

  if (!word || !variations || !Array.isArray(variations)) {
    return res.status(400).json({ message: 'Invalid word or variations' });
  }

  if (dictionary[word]) {
    return res.status(400).json({ message: 'Word already exists' });
  }

  dictionary[word] = variations;
  writeDictionary(dictionary);

  res.json({ message: 'Word created successfully' });
});

module.exports = router;
