const stringSimilarity = require('string-similarity');

// Function to find the best matches for a given word in the dictionary
const findBestMatches = (word, dictionary) => {
  let matches = {};

  // Compare the input word with all keys and variations in the dictionary
  for (let key in dictionary) {
    const keyMatch = stringSimilarity.compareTwoStrings(word, key);
    if (keyMatch > 0.4) {  // Set a threshold for similarity
      matches[key] = {
        key: key,
        similarity: keyMatch,
        variations: dictionary[key]
      };
    }

    // Check variations for similar matches
    dictionary[key].forEach(variation => {
      const variationMatch = stringSimilarity.compareTwoStrings(word, variation);
      if (variationMatch > 0.4) {
        if (!matches[key]) {
          matches[key] = { key: key, variations: [] };
        }
        matches[key].variations.push({
          variation,
          similarity: variationMatch
        });
      }
    });
  }

  // Sort the matches by similarity in descending order
  return Object.values(matches).sort((a, b) => b.similarity - a.similarity);
};

module.exports = { findBestMatches };
